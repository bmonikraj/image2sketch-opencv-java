/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package image2sketch_java_opencv;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import org.opencv.core.Core;
import org.opencv.core.Mat;

/**
 *
 * @author MONIK RAJ
 */
public class captureImage {
    public void cap(Mat mat) throws IOException{
        System.loadLibrary( Core.NATIVE_LIBRARY_NAME );
        Core.flip(mat, mat, 1);
        byte[] data1 = new byte[mat.rows() * mat.cols() * (int)(mat.elemSize())];
        mat.get(0, 0, data1);
        
        /*Matrix channel flip initiated*/
        byte b;
        for(int i=0; i<data1.length; i=i+3) {  
            b = data1[i];  
            data1[i] = data1[i+2];  
            data1[i+2] = b;  
        }   
        /*Matrix channel flip completed*/
            
        BufferedImage image1 = new BufferedImage(mat.cols(),mat.rows(), BufferedImage.TYPE_3BYTE_BGR);
        image1.getRaster().setDataElements(0, 0, mat.cols(), mat.rows(), data1);
        File ouptut = new File(System.getProperty("user.dir")+"\\abc.jpg");
        ImageIO.write(image1, "jpg", ouptut);
    }
}
