/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package image2sketch_java_opencv;
/**
 *
 * @author MONIK RAJ
 */

public class Image2Sketch_Java_OpenCV {

    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args)  throws InterruptedException{
        // TODO code application logic here
        GUI gui = new GUI();
        Thread t = new Thread(gui);
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    
}
