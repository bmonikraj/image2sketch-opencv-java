/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package image2sketch_java_opencv;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Core;
import org.opencv.imgproc.Imgproc;
import org.opencv.core.Size;

/**
 *
 * @author MONIK RAJ
 */
public class ImageProcessing {
    public boolean convertImg(){
        int check = -1;
        try {
            System.loadLibrary( Core.NATIVE_LIBRARY_NAME );
            File input = new File(System.getProperty("user.dir")+"\\abc.jpg");
            BufferedImage image = ImageIO.read(input);
            
            byte[] data = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
            Mat mat = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC3);
            mat.put(0, 0, data);
            
            Mat mat1 = new Mat(image.getHeight(),image.getWidth(),CvType.CV_8UC1);
            Imgproc.cvtColor(mat, mat1, Imgproc.COLOR_RGB2GRAY);
            
            Mat mat2 = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC1);
            Core.bitwise_not(mat1, mat2);
            
            //mat1 - gray ; mat2 - grayneg ; mat3 - blurred gray neg; mat4 - blend
            Mat mat3 = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC1);
            
            Imgproc.GaussianBlur(mat2, mat3, new Size(9,9), 0, 0);
            
            Mat mat4 = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC1);
            
            for(int i=0; i<mat1.height(); i++)
            {
                for(int j=0; j<mat1.width(); j++)
                {
                    double[] data1 = mat1.get(i, j);
                    double[] data2 = mat3.get(i, j);
                    if(data2[0]==255.0)
                    {
                        mat4.put(i, j, 255.0);
                    }
                    else
                    {
                        double k = (data1[0]*256.0)/(255.0-data2[0]);
                        if(k>255)
                        {
                            mat4.put(i, j, 255.0);
                        }
                        else
                        {
                            mat4.put(i, j, k);
                        }
                    }
                }
            }
            
            
            
            byte[] data1 = new byte[mat1.rows() * mat1.cols() * (int)(mat1.elemSize())];
            mat4.get(0, 0, data1);
            
            BufferedImage image1 = new BufferedImage(mat1.cols(),mat1.rows(), BufferedImage.TYPE_BYTE_GRAY);
            image1.getRaster().setDataElements(0, 0, mat1.cols(), mat1.rows(), data1);
            
            
            File ouptut = new File(System.getProperty("user.dir")+"\\sketch.jpg");
            ImageIO.write(image1, "jpg", ouptut);
            check = 1;
        } catch (IOException ex) {
            check = 0;
            Logger.getLogger(ImageProcessing.class.getName()).log(Level.SEVERE, null, ex);
        }   
        
        if(check==0)
            return false;
        else
            return true;
    }
}
