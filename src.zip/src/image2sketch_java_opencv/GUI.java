/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package image2sketch_java_opencv;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Core;
import org.opencv.imgproc.Imgproc;
import org.opencv.core.Size;

/**
 *
 * @author MONIK RAJ
 */
public class GUI implements Runnable{
    public Thread t = new Thread();
    
    static{ System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
    }
    public Mat cam = new Mat();
    public JFrame mainFrame;
    public JLabel imageL;
    public JPanel videoFrame;
    public JPanel actionMenu;
    public JButton captureBut;
    public JButton convertBut;
    public VideoCapture capture = new VideoCapture(0);
    public JLabel imageLabel = new JLabel();
    
    public void startGUI() throws IOException{
        mainFrame = new JFrame("Image2Sketch");
        
        actionMenu = new JPanel();
        captureBut = new JButton();
        captureBut.setText("CAPTURE IMAGE");
        convertBut = new JButton();
        convertBut.setText("CONVERT TO SKETCH");
        actionMenu.add(captureBut);
        actionMenu.add(Box.createRigidArea(new Dimension(40,60)));
        actionMenu.add(convertBut);
        actionMenu.setLayout(new BoxLayout(actionMenu,BoxLayout.X_AXIS));
        
        videoFrame = new JPanel();
        
        /*Video Display Window to be added in the videoFrame JPanel Object*/
        
        capture.set(Videoio.CAP_PROP_FRAME_WIDTH,320);
        capture.set(Videoio.CAP_PROP_FRAME_HEIGHT,240);
    
        videoFrame.add(imageLabel);
        videoFrame.setLayout(new BoxLayout(videoFrame,BoxLayout.X_AXIS));
        
        mainFrame.setResizable(true);
        mainFrame.setSize(400,400);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.add(videoFrame);
        mainFrame.add(Box.createRigidArea(new Dimension(0,20)));
        mainFrame.add(actionMenu);
        mainFrame.setLayout(new BoxLayout(mainFrame.getContentPane(),BoxLayout.Y_AXIS));
        mainFrame.setVisible(true);
        
        captureBut.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                capture.release();
                captureImage saveObject = new captureImage();
                try {
                    saveObject.cap(cam);
                } catch (IOException ex) {
                    Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        convertBut.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ImageProcessing imgp = new ImageProcessing();
                imgp.convertImg();
                System.out.println("Sketching");
                File input = new File(System.getProperty("user.dir")+"\\sketch.jpg");
                try {
                    BufferedImage image = ImageIO.read(input);
                    ImageIcon icn = new ImageIcon(image,"Capturing...");
                    imageLabel.setIcon(icn);
                } catch (IOException ex) {
                    Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
            
        });
        
        while(capture.isOpened()){
            capture.read(cam);
            if(!cam.empty()){
                Core.flip(cam, cam, 1);
                byte[] data1 = new byte[cam.rows() * cam.cols() * (int)(cam.elemSize())];
                cam.get(0, 0, data1);  
                /*Matrix channel flip initiated*/
                byte b;
                for(int i=0; i<data1.length; i=i+3) {  
                    b = data1[i];  
                    data1[i] = data1[i+2];  
                    data1[i+2] = b;  
                }   
                /*Matrix channel flip completed*/
                BufferedImage camImg = new BufferedImage(cam.cols(),cam.rows(), BufferedImage.TYPE_3BYTE_BGR);
                camImg.getRaster().setDataElements(0, 0, cam.cols(), cam.rows(), data1);                
                ImageIcon ic = new ImageIcon(camImg,"Capturing...");
                imageLabel.setIcon(ic);                
            }
        }
                
    }

    @Override
    public void run() {
        try {
            startGUI();
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void start(){
        if(t==null){
            t = new Thread(this);
            t.start();
        }
        else{
            t.start();
        }
    }

}
